
# 1.2
 * add shiny example

# 1.1
 * create_diff: add handling of filenames


# 1.0
 * diffr2
 * create_diff
