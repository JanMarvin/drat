library(testthat)
library(readspss)

test_check("readspss")
