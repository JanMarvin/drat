## ----setup, include = FALSE---------------------------------------------------
library(readstata13)
dir.create("res")
options(rmarkdown.html_vignette.check_title = FALSE)

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
data (cars)

# save file cars.dta
save.dta13(cars, file = "res/cars.dta")

# read file cars.dta
dat <- read.dta13("res/cars.dta")

## -----------------------------------------------------------------------------
# prints the attributes
attributes(dat)

## -----------------------------------------------------------------------------
# save a Stata 7 dta file
save.dta13(cars, "res/cars_version.dta", version = 7)

# read this file and print the format
dat3 <- read.dta13("res/cars_version.dta")
attr(dat3, "version")

## -----------------------------------------------------------------------------
# read rows 1 to 3
dat_1 <- read.dta13("res/cars.dta", select.rows = c(1,3)); dat_1

# read only variable "dist"
dat_2 <- read.dta13("res/cars.dta", select.cols = "dist"); head(dat_2)

## -----------------------------------------------------------------------------
# save with compression
save.dta13(cars, file = "res/cars_compress.dta", compress = TRUE)

# import and compare types
dat2 <- read.dta13(file = "res/cars_compress.dta")
attr(dat2, "types")

## -----------------------------------------------------------------------------
file.info("res/cars.dta")["size"]
file.info("res/cars_compress.dta")["size"]


## -----------------------------------------------------------------------------
# download an example created for demonstration purposes
file <- "https://github.com/sjewo/readstata13/files/1995152/Stata.dta.zip"
curl::curl_download(url = file, destfile = "res/Stata_dta.zip")

unzip("res/Stata_dta.zip", exdir = "res")

# export the strl as binary file to the current working directory
dat4 <- read.dta13("res/Stata.dta", strlexport = TRUE, strlpath = "res")


# content of both. First is a txt file second a png.
dir("res")
readLines("res/15_1")

library(magick)
img <- image_read("res/16_1")
plot(img)

## ----include=FALSE------------------------------------------------------------
unlink("res/", recursive = TRUE)

