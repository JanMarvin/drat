library(testthat)
library(readsas)

test_check("readsas")
