# nolint start

library(haven)
library(readsas)

# fls <- dir("inst/data/")
fls <- dir("~/Source/sas7bdat/")

for (fl in fls) {

  if (!(
    fl == "all_rand_normal_with_deleted.sas7bdat" | # deleted rows
    fl == "all_rand_normal_with_deleted2.sas7bdat" | # deleted rows
    fl == "all_rand_normal_with_deleted_2.sas7bdat" | # deleted rows
    # fl == "states.sas7bdat" |
    # fl == "saheart.sas7bdat" |
    fl == "comp_deleted.sas7bdat" | # deleted rows
    fl == "colon.sas7bdat" | # fehler haven: unsupported file
    fl == "dataPageWithDeleted.sas7bdat" | # deleted rows
    fl == "ccount.sas7bdat" | # fehler haven: file looks damaged
    fl == "sas_sample.sas7bdat" | # deleted rows
    fl == "test2_mod.sas7bdat" | # deleted rows
    fl == "test2.sas7bdat" | # deleted rows
    fl == "test3.sas7bdat" | # deleted rows
    fl == "test4.sas7bdat" | # deleted rows
    fl == "test5.sas7bdat" | # deleted rows
    fl == "load_log.sas7bdat" | # deleted rows
    fl == "sasmacr-2.sas7bcat" | # SAS-File ohne Daten?
    fl == "sasmacr.sas7bcat" | # SAS-File ohne Daten?
    # fl == "class.sas7bdat" |
    # fl == "cars_binary_reuse_no.sas7bdat" |
    # fl == "cars_binary_reuse.sas7bdat" |
    # fl == "cars_binary.sas7bdat" |
    # fl == "eventrepository.sas7bdat" | # tz difference
    # fl == "mroz.sas7bdat" |
    # fl == "prds_hosp10_yr2012.sas7bdat" | # fehler beide
    # fl == "acadindx_compress_yes.sas7bdat" |
    # fl == "acadindx_compress_binary.sas7bdat" | # fehler haven
    #       fl == "cars.sas7bdat" |
    fl == "pricedata_attributes.sashdat" | # fehler beide
    fl == "pricedata.sashdat" | # fehler beide
    fl == "skinproduct_attributes.sashdat" | # fehler beide
    fl == "skinproduct.sashdat" | # fehler beide
    # fl == "recapture_test_compressed.sas7bdat" |
    fl == "canada5.sas7bdat" | # fehler haven falscher offset
    fl == "canada6.sas7bdat" | # fehler haven
    fl == "cons_inc.sas7bdat" | # fehler haven
    fl == "exrate5.sas7bdat" | # fehler haven
    # fl == "foo.sas7bdat" |
    fl == "france_ep.sas7bdat" | # fehler haven
    fl == "france.sas7bdat" | # fehler haven
    fl == "zero_observations.sas7bdat" | # fehler haven
    fl == "one_observation.sas7bdat" | # fehler haven
    fl == "DCSKINPRODUCT.sas7bdat" | # no date in haven
    fl == "compression_bug.sas7bdat" | # fehler haven
    # fl == "pss1516_pu.sas7bdat"
    #       fl == "accidents.sas7bdat"
    fl %in% c("sas7bcat", "big") # folder
  )) {

    message(fl)
    # fl <- paste0("inst/data/", fl)
    fl <- paste0("~/Source/sas7bdat/", fl)
    try(hv <- haven::read_sas(fl))
    try(dd  <- readsas::read.sas(fl))
    # sas <- sas7bdat::read.sas7bdat("inst/data/hltheds2006.sas7bdat")

    # sa <- sas7bdat(fl)
    message(fl)
    stopifnot(all.equal(dd, hv, check.attributes = FALSE))
    stopifnot(all.equal(names(dd), names(hv)))
    rm(dd, hv)

  }
}


# sas <- sas7bdat::read.sas7bdat("inst/data/hltheds2006.sas7bdat")
dd <- read.sas("../sas7bdat/hltheds2006.sas7bdat")


dd <- read.sas("../sas7bdat/h_nhi_opdte10302_30.sas7bdat")

fl <- "../sas7bdat/hltheds2006.sas7bdat"
fl <- "../sas7bdat/physeds2006.sas7bdat"

hv <- read_sas(fl)
dd <- read.sas(fl)


dd <- read.sas("../sas7bdat/eventrepository.sas7bdat")
head(dd)

dd <- read.sas("../sas7bdat/acadindx.sas7bdat")
dd <- read.sas("../sas7bdat/acadindx_compress_yes.sas7bdat")
dd <- read.sas("../sas7bdat/acadindx_compress_binary.sas7bdat")

dd <- read.sas("../sas7bdat/big/pu2018.sas7bdat", select.rows = 1:2)

dd <- read.sas("../sas7bdat/person18.sas7bdat")

dd <- read.sas("../sas7bdat/prds_hosp10_yr2012.sas7bdat",
               debug = F, select.rows = 0)


# write.csv2(dd, file = "/tmp/tmpfile.csv", row.names = FALSE)
readstata13::save.dta13(dd, file = "/tmp/tmpfile.dat", version = 13)


dd <- read.sas("../sas7bdat/france.sas7bdat"); head(dd)
dd <- read.sas("../sas7bdat/poolcoll2.sas7bdat"); head(dd)
dd <- read.sas("../sas7bdat/accidents.sas7bdat"); head(dd)
attributes(dd)


dd <- read.sas("../sas7bdat/airline.sas7bdat"); head(dd)

dd <- read.sas("../sas7bdat/all_rand_normal_with_deleted.sas7bdat")
dd <- read.sas("../sas7bdat/class.sas7bdat")


fl <- "../sas7bdat/eventrepository.sas7bdat"
dd <- read.sas(fl)


fl <- "../sas7bdat//salesbyday.sas7bdat"
dd <- read.sas(fl)


dd <- read.sas("../sas7bdat/mroz.sas7bdat") # somethings odd in this file

dh <- haven::read_sas("../sas7bdat/all_rand_normal_with_deleted.sas7bdat")
dd <- read.sas("../sas7bdat/all_rand_normal_with_deleted.sas7bdat", F)
head(dd)
attributes(dd)

dd <- read.sas("../sas7bdat/a.sas7bdat")


# read.sas("~/Source/sas7bdat/pricedata.sashdat")

dd <- read.sas("../sas7bdat/comp_deleted.sas7bdat", F, select.rows = c(2, 3), select.cols = "column4")
dd <- read.sas("../parso/src/test/resources/sas7bdat/extend_yes.sas7bdat", F)


dd <- read.sas("~/Source/parso/src/test/resources/bugs/54-class.sas7bdat")
dd <- read.sas("~/Source/parso/src/test/resources/bugs/54-cookie.sas7bdat")

dd <- read.sas("~/Source/parso/src/test/resources/bugs/invalid_lengths.sas7bdat", T)
dd <- read.sas("~/Source/parso/src/test/resources/bugs/mixed_data_one.sas7bdat.oom", T)
dd <- read.sas("~/Source/parso/src/test/resources/bugs/sas_infinite_loop.sas7bdat", T)

dd <- read.sas("~/Source/sas7bdat/zero_observations.sas7bdat")
dd <- read.sas("~/Source/sas7bdat/one_observation.sas7bdat")

# nolint end
