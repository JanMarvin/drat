# nolint start

library(sas7bdat)
library(haven)
library(readsas)
library(magrittr)


# sas <- read.sas7bdat("../sas7bdat/acadindx.sas7bdat")
# hav <- read_sas("../sas7bdat/acadindx.sas7bdat")



dd <- readsas::read.sas("../sas7bdat/mtcars.sas7bdat")
dd

dd <- read.sas("../sas7bdat/mtcars.sas7bdat", select.rows = c(2,5))


dd <- readsas::read.sas("../sas7bdat/acadindx.sas7bdat")

ds <- sas7bdat::read.sas7bdat("../sas7bdat/acadindx.sas7bdat")
dh <- haven::read_sas("../sas7bdat/acadindx.sas7bdat")

all.equal(dd, dh, check.attributes = FALSE)

dd <- readsas::read.sas("../sas7bdat/agents.sas7bdat")
ds <- sas7bdat::read.sas7bdat("../sas7bdat/agents.sas7bdat")
dh <- haven::read_sas("../sas7bdat/agents.sas7bdat")

all.equal(dd, dh, check.attributes = FALSE)



dd <- readsas::read.sas("../sas7bdat/acadindx.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/acadindx_new.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/andy.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/bangla.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/banks.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/bbwt.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/beer.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/bond.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/born.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/br.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/br2.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/branches.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/brumm.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/byd.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/canada.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/candy.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/candyinfo.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/capm4.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/cars_sas.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/chard.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/capm4.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/clothes.sas7bdat"); head(dd)

dd <- readsas::read.sas("../sas7bdat/mroz.sas7bdat"); head(dd); tail(dd)


dd <- readsas::read.sas("../sas7bdat/acadindx_compress_no.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/acadindx_compress_yes.sas7bdat"); head(dd)
dd <- readsas::read.sas("../sas7bdat/acadindx_compress_binary.sas7bdat"); head(dd)

fl <- "../sas7bdat/ssocs_puf.sas7bdat"

dd <- read.sas("../sas7bdat/ssocs_puf.sas7bdat"); head(dd)
dd <- read.sas("../sas7bdat/pss1516_pu.sas7bdat"); head(dd)
dd <- read.sas("../sas7bdat/pss8990_pu.sas7bdat"); head(dd)
dd <- read.sas("../sas7bdat/prds_hosp10_yr2012.sas7bdat"); head(dd)

dd <- read.sas("../sas7bdat/prds_hosp10_yr2012.sas7bdat")


all.equal(exp[,c(1, 3)], got, check.attributes = FALSE)


dd <- read.sas("~/Source/parso/src/test/resources/sas7bdat/data_page_with_deleted.sas7bdat",
               select.cols = "VAR3")


# dd <- read.sas7bdat("../sas7bdat/andy.sas7bdat")
# read.sas7bdat("../sas7bdat/bond.sas7bdat") %>% head()
# read.sas7bdat("../sas7bdat/br.sas7bdat") %>% head()
# read.sas7bdat("../sas7bdat/byd.sas7bdat") %>% head()
# read.sas7bdat("../sas7bdat/cars.sas7bdat") %>% head()
# read.sas7bdat("../sas7bdat/poolcoll2.sas7bdat") %>%  head(dd)

# all.equal(dd, sas, check.attributes = FALSE)

fl <- "../sas7bdat/saheart.sas7bdat"
dd <- read.sas(fl)

dd <- read.sas(fl, rowcount = 90536)

fl <- "../sas7bdat/recapture_test_compressed.sas7bdat"
dd <- read.sas(fl)

hv <- haven::read_sas(fl)
head(hv)

fl <- "../sas7bdat/states.sas7bdat"
dd <- read.sas(fl, debug = F)

fl <- "../sas7bdat/all_rand_normal.sas7bdat"
dd <- read.sas(fl, F)

fl <- "../sas7bdat/all_rand_normal_with_deleted.sas7bdat"
dd <- read.sas(fl)

fl <- "../sas7bdat/all_rand_normal_with_deleted_2.sas7bdat"
dd <- read.sas(fl, F)

fl <- "~/Source/sas7bdat/test.sas7bdat"
dd <- read.sas(fl, F)

fl <- "~/Source/sas7bdat/test2.sas7bdat" # 64 | 2
dd <- read.sas(fl, F) # delete x = 2

fl <- "~/Source/sas7bdat/test3.sas7bdat" # 96 | 2.68156e+154
dd <- read.sas(fl, F) # delete x > 1

fl <- "~/Source/sas7bdat/test4.sas7bdat" # 128 | -0
dd <- read.sas(fl, F) # delte x = 1

fl <- "~/Source/sas7bdat/test5.sas7bdat" # 192 | -2
dd <- read.sas(fl, F) # delete x < 3


library(microbenchmark)

fl <- "~/Source/sas7bdat/acadindx.sas7bdat"
# fl <- "../sas7bdat/all_rand_normal.sas7bdat"

res <- microbenchmark(
  dd <- readsas::read.sas(fl),
  hv <- haven::read_sas(fl),
  times = 50
); res

readsas::read.sas("~/Source/sas7bdat/highdate_fails.sas7bdat")


readsas::read.sas("~/Source/sas7bdat/catch_19811.sas7bdat")
haven::read_sas("~/Source/sas7bdat/catch_19811.sas7bdat")

readsas::read.sas("~/Source/sas7bdat/sasmacr.sas7bcat", F)
readsas::read.sas("~/Source/sas7bdat/sasmacr-2.sas7bcat", F)

dd <- readsas::read.sas("~/Source/sas7bdat/compression_bug.sas7bdat")
hv <- haven::read_sas("~/Source/sas7bdat/compression_bug.sas7bdat")


# tmp <- readsas::read.sas("~/Source/sas7bdat/big/pu2018.sas7bdat", F, rowcount = 1)
tmp <- readsas::read.sas("~/Source/sas7bdat/big/pu2018.sas7bdat", select.rows = 1)

tmp <- readsas::read.sas("~/Source/sas7bdat/big/pu2018.sas7bdat",
                         # select.rows = 1,
                         select.cols = c("SSUID", "ARVDEBT", "EOWN_PENSION"))

dd <- readsas::read.sas("~/Source/sas7bdat/file.sas7bdat")

### local tests

# no compression with deleted
exp <- read.sas("~/Source/parso/src/test/resources/sas7bdat/data_page_with_deleted.sas7bdat")[,c(1, 3)]
got <- read.sas("~/Source/parso/src/test/resources/sas7bdat/data_page_with_deleted.sas7bdat",
                select.cols = c("VAR1", "VAR3"))
all.equal(exp, got, check.attributes = FALSE)


# compression with deleted
exp <- read.sas("~/Source/parso/src/test/resources/sas7bdat/comp_deleted.sas7bdat")[,c(2, 4)]
got <- read.sas("~/Source/parso/src/test/resources/sas7bdat/comp_deleted.sas7bdat",
                select.cols = c("olumn2", "column4"))
all.equal(exp, got, check.attributes = FALSE)


# compression with deleted
exp <- read.sas("~/Source/parso/src/test/resources/sas7bdat/tmp868_14.sas7bdat")[700:750, c("x4", "x11")]
got <- read.sas("~/Source/parso/src/test/resources/sas7bdat/tmp868_14.sas7bdat",
                select.cols = c("x4", "x11"), select.rows = c(700, 750))
all.equal(exp, got, check.attributes = FALSE)


# nolint end
